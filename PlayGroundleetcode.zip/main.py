height = [2, 1, 0, 2, 1, 0, 1, 3, 2, 1, 2, 1]
#This problem has to be solved in O(n)

#Let's start with processing one index, from 1 to n-2
#determine two endpoints which contains water.

#stack
stack = []
answer = 0
ln = len(height)

